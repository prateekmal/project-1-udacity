In this problem, first I have created a set for making union & intersection of the two linked list. Then I have created a new linked list from the set.

Union:
Time complexity: O(n)
Space complexity: O(n)

intersection:
Time complexity: O(n)
Space complexity: O(n)
